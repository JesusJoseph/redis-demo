package com.redis.example.entity;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.redis.core.RedisHash;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
@RedisHash("Product")
public class Product implements Serializable {

    private static final long serialVersionUID = 1610137414663340040L;

    @Id
    private Long productId;

    private String name;

    private String description;

    private Integer quantity;

    private Long price;
}
