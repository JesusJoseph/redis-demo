package com.redis.example.repo;

import com.redis.example.entity.Product;  // Make sure the correct import statement is used
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.GenericJackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.SerializationException;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import java.util.List;

//@Service
@Repository
public class ProductRepositoryData implements ProductRepository {

    public static final String HASH_KEY = "Product";

    static final Logger logger = LoggerFactory.getLogger(ProductRepositoryData.class);

    @Autowired
    private RedisTemplate template;

    @Override
    public Product createProduct(Product product) {
        Long productId = generateProductId();
        product.setProductId(productId);
        template.opsForHash().put(HASH_KEY, productId.toString(), product);
        return product;
    }

    private Long generateProductId() {
        Long productId = System.currentTimeMillis();
        // Ensure that the generated ID is non-null
        return (productId != null) ? productId : System.currentTimeMillis();
    }

    @Override
    public List<Product> getAllProducts() {
        //template.setValueSerializer(new GenericJackson2JsonRedisSerializer());
        return template.opsForHash().values(HASH_KEY);
    }

    @Override
    @Cacheable(key = "#id", value ="Product")
    public Product findProductById(Long id) {
        try {
            System.out.println("Called By Id from DB");
            String productIdAsString = id.toString();
            logger.info("Searching for product with ID: {}", productIdAsString);
            Product product = (Product) template.opsForHash().get(HASH_KEY, productIdAsString);
            logger.info("Product found: {}", product);
            return product;
        } catch (SerializationException e) {
            logger.error("Error during deserialization: {}", e.getMessage());
            return null;
        }
    }


    @Override
    @CacheEvict(key = "#id", value ="Product")
    public Product deleteProduct(Long id) {
        String productIdAsString = id.toString();
        Product deletedProduct = (Product) template.opsForHash().get(HASH_KEY, productIdAsString);

        if (deletedProduct != null) {
            template.opsForHash().delete(HASH_KEY, productIdAsString);
        }
        return deletedProduct;
    }
}
