package com.redis.example.repo;

import com.redis.example.entity.Product;
import org.springframework.http.ResponseEntity;

import java.util.List;

public interface ProductRepository {
    Product createProduct(Product product);

    List<Product> getAllProducts();

    Product findProductById(Long id);

    Product deleteProduct(Long id);
}
